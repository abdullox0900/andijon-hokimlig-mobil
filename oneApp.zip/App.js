import * as React from 'react';
import MainContainer from './Components/Navigation/MainContainer';

function App() {
  return (
    <MainContainer />
  );
}

export default App;